﻿#include <iostream>
#include <fstream>
#include <vector>
#include <windows.h>

using namespace std;

class BMPImage {
private:
    BITMAPFILEHEADER fileHeader;
    BITMAPINFOHEADER infoHeader;
    vector<unsigned char> pixelData;
    int width, height, rowSize;

public:
    BMPImage() : width(0), height(0), rowSize(0) {}

    bool load(const string& filename) {
        ifstream file(filename, ios::binary);
        if (!file) {
            cerr << "Ошибка: не удалось открыть файл " << filename << endl;
            return false;
        }

        file.read(reinterpret_cast<char*>(&fileHeader), sizeof(BITMAPFILEHEADER));
        file.read(reinterpret_cast<char*>(&infoHeader), sizeof(BITMAPINFOHEADER));

        if (infoHeader.biBitCount != 24 && infoHeader.biBitCount != 32) {
            cerr << "Ошибка: поддерживаются только 24-битные и 32-битные BMP файлы.\n";
            return false;
        }

        width = infoHeader.biWidth;
        height = abs(infoHeader.biHeight);
        rowSize = ((width * (infoHeader.biBitCount / 8) + 3) / 4) * 4;

        pixelData.resize(rowSize * height);
        file.seekg(fileHeader.bfOffBits, ios::beg);
        file.read(reinterpret_cast<char*>(pixelData.data()), pixelData.size());

        file.close();
        return true;
    }

    void display() const {
        for (int y = height - 1; y >= 0; --y) {
            for (int x = 0; x < width; ++x) {
                int index = y * rowSize + x * (infoHeader.biBitCount / 8);
                unsigned char blue = pixelData[index];
                unsigned char green = pixelData[index + 1];
                unsigned char red = pixelData[index + 2];

                if (red == 0 && green == 0 && blue == 0) {
                    cout << "#";
                }
                else if (red == 255 && green == 255 && blue == 255) {
                    cout << " ";
                }
                else {
                    cerr << "Ошибка: картинка содержит неподдерживаемые цвета.\n";
                    return;
                }
            }
            cout << endl;
        }
    }

    void drawLine(int x1, int y1, int x2, int y2) {
        int dx = abs(x2 - x1), dy = abs(y2 - y1);
        int sx = (x1 < x2) ? 1 : -1, sy = (y1 < y2) ? 1 : -1;
        int err = dx - dy;

        while (true) {
            setPixel(x1, y1, 0, 0, 0);

            if (x1 == x2 && y1 == y2) break;

            int e2 = 2 * err;
            if (e2 > -dy) { err -= dy; x1 += sx; }
            if (e2 < dx) { err += dx; y1 += sy; }
        }
    }

    void drawCross() {
        int midX = width / 2;
        int midY = height / 2;
        drawLine(0, midY, width - 1, midY);
        drawLine(midX, 0, midX, height - 1);
    }

    void save(const string& filename) const {
        ofstream file(filename, ios::binary);
        if (!file) {
            cerr << "Ошибка: не удалось создать файл " << filename << endl;
            return;
        }

        file.write(reinterpret_cast<const char*>(&fileHeader), sizeof(BITMAPFILEHEADER));
        file.write(reinterpret_cast<const char*>(&infoHeader), sizeof(BITMAPINFOHEADER));
        file.write(reinterpret_cast<const char*>(pixelData.data()), pixelData.size());

        file.close();
    }

private:
    void setPixel(int x, int y, unsigned char r, unsigned char g, unsigned char b) {
        if (x < 0 || x >= width || y < 0 || y >= height) return;
        int index = y * rowSize + x * (infoHeader.biBitCount / 8);
        pixelData[index] = b;
        pixelData[index + 1] = g;
        pixelData[index + 2] = r;
    }
};

int main() {
    string inputFile, outputFile;

    cout << ">> Enter input BMP file name: ";
    cin >> inputFile;

    BMPImage image;
    if (!image.load(inputFile)) return 1;

    cout << "Исходное изображение:\n";
    image.display();

    image.drawCross();
    cout << "Изображение после рисования креста:\n";
    image.display();

    cout << ">> Enter output BMP file name: ";
    cin >> outputFile;

    image.save(outputFile);
    cout << "Файл сохранен: " << outputFile << endl;

    return 0;
}
